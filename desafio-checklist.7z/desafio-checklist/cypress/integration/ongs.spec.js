/// <reference types="cypress" />



describe ('Ongs',() => {

    it ('Consulta e acessa um URL', () => {

        cy.visit('https://www.globo.com/')    
        cy.wait(1000);   
    });
    it ('Pesquisa por texto', () => {
        cy.get('#header-search-input').click({force: true }).type('Florianópolis').type('{enter}');
        cy.wait(1000);
    });

    it ('Abre uma das notícias da página', () => {
        cy.get('.widget--info__media-container').click({multiple: true}) 
    });
});