1- Faça o download do arquivo desafio-checklist.zip;
2- Descompacte-o em sua máquina, na pasta Documentos (é necessário que o projeto esteja no disco C, para que sejam importados os elementos do node)
3- Abra o projeto em um IDE de programação (ex: vscode)
4-